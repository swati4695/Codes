package com.espire.cabbooking1.dao;

import java.sql.SQLException;

public interface AdminDao {
	public void viewAllCabs() throws SQLException;
	public void viewAllPassengers() throws SQLException;
	public void viewAllBookings() throws SQLException;
}
