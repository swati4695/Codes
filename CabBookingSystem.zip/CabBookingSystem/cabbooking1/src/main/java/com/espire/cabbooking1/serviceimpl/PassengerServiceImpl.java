package com.espire.cabbooking1.serviceimpl;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.Date;
import java.util.Scanner;
import com.espire.cabbooking1.connection.DBConnection;
import com.espire.cabbooking1.service.PassengerService;


public class PassengerServiceImpl implements PassengerService{
	DBConnection connection = new DBConnection();
    Scanner scan=new Scanner(System.in);
	public void add(int bId, Timestamp date, String bStatus) throws SQLException {
		String sql = "insert into booking(bookingId,bookingDateTime,bookingStatus) values(" + bId + ",'"
				+ date + "','" + bStatus + "')";
		Connection con = connection.getCon();
		Statement st = con.createStatement();
		int n = st.executeUpdate(sql);
		if (n >= 0)
			System.out.println(" Cab Booked");
		return;
	}

	public void delete(int bId) throws SQLException {
		String sql = "delete from booking where bookingId="+bId;
		Connection con = connection.getCon();
		Statement st = con.createStatement();
		int n = st.executeUpdate(sql);
		if (n >= 0)
			System.out.println("Ride Canclled");
		return;
	}

}
