package com.espire.cabbooking1.serviceimpl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import com.espire.cabbooking1.Booking;
import com.espire.cabbooking1.Cab;
import com.espire.cabbooking1.Passenger;
import com.espire.cabbooking1.connection.DBConnection;
import com.espire.cabbooking1.service.AdminService;

public class AdminServiceImpl implements AdminService{
	DBConnection connection = new DBConnection();

	@Override
	public Cab getAllCabs() throws SQLException{
		String sql="select*from Cab";
		Connection con = connection.getCon();
		Statement st = con.createStatement();
		ResultSet rs=st.executeQuery(sql);
		while(rs.next()) {
			System.out.println(rs.getInt(1)+" "+rs.getInt(2)+" "+rs.getString(3)+" "+rs.getString(4)+" "+rs.getString(5));
		}
		return null;
	}

	@Override
	public Passenger getAllPassengers() throws SQLException {
		String sql="select*from Passenger";
		Connection con = connection.getCon();
		Statement st = con.createStatement();
		ResultSet rs=st.executeQuery(sql);
		while(rs.next()) {
			System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getString(4));
		}
		return null;
	}

	@Override
	public Booking getAllBookings() throws SQLException {
		String sql="select*from Booking";
		Connection con = connection.getCon();
		Statement st = con.createStatement();
		ResultSet rs=st.executeQuery(sql);
		while(rs.next()) {
			System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getString(5));
		}
		return null;
	}

}
