package com.espire.cabbooking1;

import java.sql.Timestamp;

public class Booking {
	private int bookingId;
	private Timestamp bookingDateTime ;
	private String bookingStatus ;
	private boolean check;
	
	public Booking() {}
	public Booking(int bookingId, Timestamp bookingDateTime, String bookingStatus, boolean check) {
		this.bookingId = bookingId;
		this.bookingDateTime = bookingDateTime;
		this.bookingStatus = bookingStatus;
		this.check = check;
	}
	
	public int getBookingId() {
		return bookingId;
	}
	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}
	public Timestamp getBookingDateTime() {
		return bookingDateTime;
	}
	public void setBookingDateTime(Timestamp bookingDateTime) {
		this.bookingDateTime = bookingDateTime;
	}
	public String getBookingStatus() {
		return bookingStatus;
	}
	public void setBookingStatus(String bookingStatus) {
		this.bookingStatus = bookingStatus;
	}
	public boolean isCheck() {
		return check;
	}
	public void setCheck(boolean check) {
		this.check = check;
	}
	@Override
	public String toString() {
		return "Booking [bookingId=" + bookingId + ", bookingDateTime=" + bookingDateTime + ", bookingStatus="
				+ bookingStatus + ", check=" + check + "]";
	}
	
}
