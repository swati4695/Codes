package com.mybill.ui;

import java.text.DecimalFormat;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.mybill.bean.BillCalculator;
import com.mybill.configuration.SpringConfig;



public class UserInterface {

	public static void main(String[] args) {
		ApplicationContext applicationContext = new AnnotationConfigApplicationContext(SpringConfig.class);
        BillCalculator billCalculator = (BillCalculator) applicationContext.getBean(BillCalculator.class);
        
        String pattern="##.0";
        DecimalFormat df=new DecimalFormat(pattern);
        
        System.out.println("Total bill to pay is $"+(df.format(billCalculator.calculateBill())));
        
      //  System.out.println(billCalculator.calculateBill());
	}

}
