package com.mybill.spring;

import java.text.DecimalFormat;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;



public class App {
    public static void main( String[] args ){
      //spring configuration class invoked
       ApplicationContext context = new ClassPathXmlApplicationContext("Spring.xml");
        BillCalculator bill = (BillCalculator)context.getBean("bill");
        // decimal format
        String pattern="##.0";
        DecimalFormat df=new DecimalFormat(pattern);
        //CalculateBill method is called
        System.out.println("Total bill to pay is $"+(df.format(bill.calculateBill())));
        }
}