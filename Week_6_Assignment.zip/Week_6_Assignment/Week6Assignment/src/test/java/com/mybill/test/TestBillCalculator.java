package com.mybill.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.mybill.spring.BillCalculator;

class TestBillCalculator {

	 BillCalculator bcal= new BillCalculator(100,0.18,10.0);

	   @Test
	    void testCalculateBill() {
	        assertEquals(1180.39, bcal.calculateBill(), 0.4);
	}

}
